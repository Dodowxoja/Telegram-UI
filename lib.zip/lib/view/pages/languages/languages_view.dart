import 'package:flutter/material.dart';

class LanguagesView extends StatelessWidget {
  const LanguagesView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
